// Advanced Features for Couple Tracker
class AdvancedFeatures {
    constructor(mainApp) {
        this.app = mainApp;
        this.geofences = [];
        this.locationHistory = [];
        this.batteryInfo = null;
        this.networkInfo = null;
        
        this.init();
    }

    init() {
        this.setupGeofencing();
        this.setupBatteryMonitoring();
        this.setupNetworkMonitoring();
        this.setupLocationHistory();
        this.setupEmergencyFeatures();
    }

    // Geofencing - Safe zones and alerts
    setupGeofencing() {
        this.geofences = [
            {
                id: 'home',
                name: 'Home',
                center: { lat: 0, lng: 0 },
                radius: 100, // meters
                type: 'safe',
                notifications: true
            },
            {
                id: 'work',
                name: 'Work',
                center: { lat: 0, lng: 0 },
                radius: 200,
                type: 'safe',
                notifications: false
            }
        ];
    }

    addGeofence(name, location, radius, type = 'safe') {
        const geofence = {
            id: Date.now().toString(),
            name,
            center: location,
            radius,
            type,
            notifications: true,
            created: new Date().toISOString()
        };
        
        this.geofences.push(geofence);
        this.saveGeofences();
        this.app.showNotification(`Geofence "${name}" created`, 'success');
        
        return geofence;
    }

    checkGeofences(currentLocation) {
        this.geofences.forEach(geofence => {
            const distance = this.calculateDistance(
                currentLocation.latitude,
                currentLocation.longitude,
                geofence.center.lat,
                geofence.center.lng
            );

            const isInside = distance <= geofence.radius;
            const wasInside = geofence.lastStatus === 'inside';

            if (isInside && !wasInside) {
                this.onGeofenceEnter(geofence, currentLocation);
            } else if (!isInside && wasInside) {
                this.onGeofenceExit(geofence, currentLocation);
            }

            geofence.lastStatus = isInside ? 'inside' : 'outside';
        });
    }

    onGeofenceEnter(geofence, location) {
        if (geofence.notifications) {
            this.app.showNotification(`Entered ${geofence.name}`, 'info');
            this.app.sendNotification(
                'Location Update',
                `Your partner entered ${geofence.name}`
            );
        }
        
        this.logGeofenceEvent('enter', geofence, location);
    }

    onGeofenceExit(geofence, location) {
        if (geofence.notifications) {
            this.app.showNotification(`Left ${geofence.name}`, 'info');
            this.app.sendNotification(
                'Location Update',
                `Your partner left ${geofence.name}`
            );
        }
        
        this.logGeofenceEvent('exit', geofence, location);
    }

    logGeofenceEvent(action, geofence, location) {
        const event = {
            id: Date.now().toString(),
            action,
            geofence: geofence.name,
            location,
            timestamp: new Date().toISOString()
        };
        
        const events = JSON.parse(localStorage.getItem('geofence_events') || '[]');
        events.push(event);
        
        // Keep only last 100 events
        if (events.length > 100) {
            events.splice(0, events.length - 100);
        }
        
        localStorage.setItem('geofence_events', JSON.stringify(events));
    }

    // Battery monitoring
    setupBatteryMonitoring() {
        if ('getBattery' in navigator) {
            navigator.getBattery().then(battery => {
                this.batteryInfo = {
                    level: battery.level,
                    charging: battery.charging,
                    chargingTime: battery.chargingTime,
                    dischargingTime: battery.dischargingTime
                };

                // Monitor battery events
                battery.addEventListener('chargingchange', () => {
                    this.batteryInfo.charging = battery.charging;
                    this.onBatteryChange();
                });

                battery.addEventListener('levelchange', () => {
                    this.batteryInfo.level = battery.level;
                    this.onBatteryChange();
                });

                this.onBatteryChange();
            });
        }
    }

    onBatteryChange() {
        // Alert partner if battery is low
        if (this.batteryInfo.level <= 0.15 && !this.batteryInfo.charging) {
            this.app.sendNotification(
                'Low Battery Alert',
                `Your partner's battery is at ${Math.round(this.batteryInfo.level * 100)}%`
            );
        }

        // Update UI
        this.updateBatteryDisplay();
    }

    updateBatteryDisplay() {
        const batteryElement = document.getElementById('batteryStatus');
        if (batteryElement && this.batteryInfo) {
            const level = Math.round(this.batteryInfo.level * 100);
            const status = this.batteryInfo.charging ? 'Charging' : 'Not charging';
            
            batteryElement.innerHTML = `
                <div class="battery-info">
                    🔋 ${level}% (${status})
                </div>
            `;
        }
    }

    // Network monitoring
    setupNetworkMonitoring() {
        if ('connection' in navigator) {
            this.networkInfo = {
                type: navigator.connection.effectiveType,
                downlink: navigator.connection.downlink,
                rtt: navigator.connection.rtt
            };

            navigator.connection.addEventListener('change', () => {
                this.networkInfo = {
                    type: navigator.connection.effectiveType,
                    downlink: navigator.connection.downlink,
                    rtt: navigator.connection.rtt
                };
                
                this.onNetworkChange();
            });
        }

        // Monitor online/offline status
        window.addEventListener('online', () => {
            this.app.showNotification('Connection restored', 'success');
        });

        window.addEventListener('offline', () => {
            this.app.showNotification('Connection lost - working offline', 'warning');
        });
    }

    onNetworkChange() {
        // Adjust location update frequency based on connection
        if (this.networkInfo.type === 'slow-2g' || this.networkInfo.type === '2g') {
            // Reduce update frequency for slow connections
            this.app.locationUpdateInterval = 60000; // 1 minute
        } else {
            this.app.locationUpdateInterval = 30000; // 30 seconds
        }
    }

    // Location history and analytics
    setupLocationHistory() {
        this.locationHistory = JSON.parse(localStorage.getItem('location_history') || '[]');
    }

    addLocationToHistory(location) {
        const historyEntry = {
            ...location,
            id: Date.now().toString(),
            speed: location.speed || 0,
            heading: location.heading || 0
        };

        this.locationHistory.push(historyEntry);

        // Keep only last 1000 locations
        if (this.locationHistory.length > 1000) {
            this.locationHistory = this.locationHistory.slice(-1000);
        }

        localStorage.setItem('location_history', JSON.stringify(this.locationHistory));
        
        // Check geofences
        this.checkGeofences(location);
        
        // Analyze movement patterns
        this.analyzeMovement();
    }

    analyzeMovement() {
        if (this.locationHistory.length < 2) return;

        const recent = this.locationHistory.slice(-10);
        const speeds = recent.map(loc => loc.speed || 0);
        const avgSpeed = speeds.reduce((a, b) => a + b, 0) / speeds.length;

        // Detect if user is stationary, walking, driving, etc.
        let movementType = 'stationary';
        if (avgSpeed > 1) movementType = 'walking';
        if (avgSpeed > 15) movementType = 'driving';
        if (avgSpeed > 80) movementType = 'fast_transport';

        // Update movement status
        this.updateMovementStatus(movementType, avgSpeed);
    }

    updateMovementStatus(type, speed) {
        const statusElement = document.getElementById('movementStatus');
        if (statusElement) {
            const icons = {
                stationary: '🏠',
                walking: '🚶',
                driving: '🚗',
                fast_transport: '✈️'
            };

            statusElement.innerHTML = `
                <div class="movement-status">
                    ${icons[type]} ${type.replace('_', ' ')} (${Math.round(speed)} km/h)
                </div>
            `;
        }
    }

    // Emergency features
    setupEmergencyFeatures() {
        // Shake detection for emergency
        if ('DeviceMotionEvent' in window) {
            let lastShake = 0;
            let shakeCount = 0;

            window.addEventListener('devicemotion', (event) => {
                const acceleration = event.accelerationIncludingGravity;
                const total = Math.abs(acceleration.x) + Math.abs(acceleration.y) + Math.abs(acceleration.z);

                if (total > 30) {
                    const now = Date.now();
                    if (now - lastShake > 1000) {
                        shakeCount = 0;
                    }
                    
                    shakeCount++;
                    lastShake = now;

                    if (shakeCount >= 3) {
                        this.triggerShakeEmergency();
                        shakeCount = 0;
                    }
                }
            });
        }

        // Panic button (volume buttons)
        let volumeDownCount = 0;
        let lastVolumeDown = 0;

        document.addEventListener('keydown', (event) => {
            if (event.key === 'VolumeDown') {
                const now = Date.now();
                if (now - lastVolumeDown < 2000) {
                    volumeDownCount++;
                } else {
                    volumeDownCount = 1;
                }
                
                lastVolumeDown = now;

                if (volumeDownCount >= 5) {
                    this.triggerPanicButton();
                    volumeDownCount = 0;
                }
            }
        });
    }

    triggerShakeEmergency() {
        this.app.showNotification('Shake emergency detected!', 'error');
        this.app.triggerEmergency();
    }

    triggerPanicButton() {
        this.app.showNotification('Panic button activated!', 'error');
        this.app.triggerEmergency();
    }

    // Smart notifications
    shouldSendNotification(type, data) {
        const settings = JSON.parse(localStorage.getItem('notification_settings') || '{}');
        
        // Don't send notifications during quiet hours
        const now = new Date();
        const hour = now.getHours();
        const quietStart = settings.quietHoursStart || 22;
        const quietEnd = settings.quietHoursEnd || 7;
        
        if (hour >= quietStart || hour <= quietEnd) {
            return false;
        }

        // Rate limiting
        const lastNotification = localStorage.getItem(`last_${type}_notification`);
        const minInterval = settings[`${type}_interval`] || 300000; // 5 minutes default
        
        if (lastNotification && Date.now() - parseInt(lastNotification) < minInterval) {
            return false;
        }

        localStorage.setItem(`last_${type}_notification`, Date.now().toString());
        return true;
    }

    // Utility functions
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c * 1000; // Return in meters
    }

    deg2rad(deg) {
        return deg * (Math.PI/180);
    }

    saveGeofences() {
        localStorage.setItem('geofences', JSON.stringify(this.geofences));
    }

    loadGeofences() {
        const saved = localStorage.getItem('geofences');
        if (saved) {
            this.geofences = JSON.parse(saved);
        }
    }

    // Export location data
    exportLocationData() {
        const data = {
            history: this.locationHistory,
            geofences: this.geofences,
            events: JSON.parse(localStorage.getItem('geofence_events') || '[]'),
            exported: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `couple-tracker-data-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        this.app.showNotification('Location data exported', 'success');
    }

    // Clear all data
    clearAllData() {
        if (confirm('Are you sure you want to clear all location data? This cannot be undone.')) {
            localStorage.removeItem('location_history');
            localStorage.removeItem('geofences');
            localStorage.removeItem('geofence_events');
            localStorage.removeItem('notification_settings');
            
            this.locationHistory = [];
            this.geofences = [];
            
            this.app.showNotification('All data cleared', 'info');
        }
    }
}

// Initialize advanced features when main app is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.coupleTracker) {
            window.coupleTracker.advancedFeatures = new AdvancedFeatures(window.coupleTracker);
        }
    }, 1000);
});