// Couple Tracker - Main Application Logic
class CoupleTracker {
    constructor() {
        this.currentUser = null;
        this.partner = null;
        this.connectionCode = null;
        this.isLocationActive = false;
        this.watchId = null;
        this.locationHistory = [];
        this.notifications = {
            enabled: false,
            permission: 'default'
        };
        this.privacyZones = [];
        this.emergencyMode = false;
        
        // Simulated WebSocket connection for real-time updates
        this.connection = null;
        this.connectionStatus = 'disconnected';
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadStoredData();
        this.checkNotificationPermission();
        this.initializeUI();
        
        // Check if there's a connection code in URL
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        if (code) {
            this.joinWithCode(code);
        }
    }

    setupEventListeners() {
        // Location toggle
        const locationToggle = document.getElementById('locationToggle');
        if (locationToggle) {
            locationToggle.addEventListener('change', (e) => {
                this.toggleLocationSharing(e.target.checked);
            });
        }

        // Generate connection code
        const generateCodeBtn = document.getElementById('generateCode');
        if (generateCodeBtn) {
            generateCodeBtn.addEventListener('click', () => {
                this.generateConnectionCode();
            });
        }

        // Join with code
        const joinCodeBtn = document.getElementById('joinCode');
        if (joinCodeBtn) {
            joinCodeBtn.addEventListener('click', () => {
                const code = document.getElementById('codeInput').value.trim();
                if (code) {
                    this.joinWithCode(code);
                }
            });
        }

        // Copy code button
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('copy-btn')) {
                this.copyToClipboard(e.target.dataset.text);
            }
        });

        // Hidden menu toggle
        const menuTrigger = document.getElementById('hiddenMenuTrigger');
        const menuItems = document.getElementById('hiddenMenuItems');
        if (menuTrigger && menuItems) {
            menuTrigger.addEventListener('click', () => {
                menuItems.classList.toggle('show');
            });

            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!menuTrigger.contains(e.target) && !menuItems.contains(e.target)) {
                    menuItems.classList.remove('show');
                }
            });
        }

        // Emergency button
        const emergencyBtn = document.getElementById('emergencyBtn');
        if (emergencyBtn) {
            emergencyBtn.addEventListener('click', () => {
                this.triggerEmergency();
            });
        }

        // Notification permission
        const notificationBtn = document.getElementById('enableNotifications');
        if (notificationBtn) {
            notificationBtn.addEventListener('click', () => {
                this.requestNotificationPermission();
            });
        }

        // Disconnect button
        const disconnectBtn = document.getElementById('disconnectBtn');
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => {
                this.disconnect();
            });
        }

        // Privacy zone toggle
        const privacyToggle = document.getElementById('privacyZone');
        if (privacyToggle) {
            privacyToggle.addEventListener('change', (e) => {
                this.togglePrivacyZone(e.target.checked);
            });
        }
    }

    loadStoredData() {
        // Load user data from localStorage
        const userData = localStorage.getItem('coupleTracker_user');
        if (userData) {
            this.currentUser = JSON.parse(userData);
        }

        const connectionData = localStorage.getItem('coupleTracker_connection');
        if (connectionData) {
            const data = JSON.parse(connectionData);
            this.connectionCode = data.code;
            this.partner = data.partner;
        }

        const notificationData = localStorage.getItem('coupleTracker_notifications');
        if (notificationData) {
            this.notifications = JSON.parse(notificationData);
        }

        const historyData = localStorage.getItem('coupleTracker_history');
        if (historyData) {
            this.locationHistory = JSON.parse(historyData);
        }
    }

    saveData() {
        if (this.currentUser) {
            localStorage.setItem('coupleTracker_user', JSON.stringify(this.currentUser));
        }
        
        if (this.connectionCode || this.partner) {
            localStorage.setItem('coupleTracker_connection', JSON.stringify({
                code: this.connectionCode,
                partner: this.partner
            }));
        }

        localStorage.setItem('coupleTracker_notifications', JSON.stringify(this.notifications));
        localStorage.setItem('coupleTracker_history', JSON.stringify(this.locationHistory));
    }

    initializeUI() {
        this.updateConnectionStatus();
        this.updateLocationStatus();
        this.updateNotificationStatus();
        
        if (this.connectionCode) {
            this.displayConnectionCode();
        }
        
        if (this.partner) {
            this.displayPartnerInfo();
        }
    }

    generateConnectionCode() {
        // Generate a unique 6-digit code
        this.connectionCode = Math.random().toString(36).substr(2, 6).toUpperCase();
        
        // Initialize current user if not exists
        if (!this.currentUser) {
            this.currentUser = {
                id: this.generateUserId(),
                name: 'You',
                avatar: '💕',
                joinedAt: new Date().toISOString()
            };
        }

        this.displayConnectionCode();
        this.saveData();
        this.showNotification('Connection code generated! Share it with your partner.', 'success');
        
        // Simulate connection establishment
        this.simulateConnection();
    }

    displayConnectionCode() {
        const codeDisplay = document.getElementById('connectionCodeDisplay');
        if (codeDisplay && this.connectionCode) {
            const shareUrl = `${window.location.origin}${window.location.pathname}?code=${this.connectionCode}`;
            
            codeDisplay.innerHTML = `
                <div class="connection-code">
                    <div class="code">${this.connectionCode}</div>
                    <p>Share this code or link with your partner</p>
                    <button class="copy-btn" data-text="${this.connectionCode}">Copy Code</button>
                    <button class="copy-btn" data-text="${shareUrl}">Copy Link</button>
                </div>
            `;
            codeDisplay.style.display = 'block';
        }
    }

    async joinWithCode(code) {
        if (!code || code.length !== 6) {
            this.showNotification('Please enter a valid 6-character code', 'error');
            return;
        }

        this.showNotification('Connecting to partner...', 'info');
        
        // Simulate connection process
        setTimeout(() => {
            this.connectionCode = code;
            this.partner = {
                id: this.generateUserId(),
                name: 'Partner',
                avatar: '💖',
                status: 'online',
                lastSeen: new Date().toISOString(),
                location: null
            };

            if (!this.currentUser) {
                this.currentUser = {
                    id: this.generateUserId(),
                    name: 'You',
                    avatar: '💕',
                    joinedAt: new Date().toISOString()
                };
            }

            this.connectionStatus = 'connected';
            this.updateConnectionStatus();
            this.displayPartnerInfo();
            this.saveData();
            this.showNotification('Successfully connected to your partner!', 'success');
            
            // Clear the input
            const codeInput = document.getElementById('codeInput');
            if (codeInput) codeInput.value = '';
            
            // Start location sharing if enabled
            if (this.isLocationActive) {
                this.startLocationTracking();
            }
        }, 2000);
    }

    displayPartnerInfo() {
        const partnerInfo = document.getElementById('partnerInfo');
        if (partnerInfo && this.partner) {
            partnerInfo.innerHTML = `
                <div class="location-card">
                    <div class="location-avatar">${this.partner.avatar}</div>
                    <div class="location-info">
                        <h3>${this.partner.name}</h3>
                        <p class="status-indicator status-${this.partner.status}">
                            <span class="status-dot"></span>
                            ${this.partner.status}
                        </p>
                        <p>Last seen: ${this.formatTime(this.partner.lastSeen)}</p>
                        ${this.partner.location ? `
                            <p>📍 ${this.partner.location.address || 'Location shared'}</p>
                            <p>🕒 ${this.formatTime(this.partner.location.timestamp)}</p>
                        ` : '<p>Location not shared</p>'}
                    </div>
                </div>
            `;
            partnerInfo.style.display = 'block';
        }
    }

    toggleLocationSharing(enabled) {
        this.isLocationActive = enabled;
        
        if (enabled) {
            this.requestLocationPermission();
        } else {
            this.stopLocationTracking();
        }
        
        this.updateLocationStatus();
        this.saveData();
    }

    async requestLocationPermission() {
        if (!navigator.geolocation) {
            this.showNotification('Geolocation is not supported by this browser', 'error');
            return false;
        }

        try {
            // Request permission and get initial position
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                });
            });

            this.showNotification('Location access granted', 'success');
            this.startLocationTracking();
            return true;
        } catch (error) {
            this.showNotification('Location access denied. Please enable location services.', 'error');
            this.isLocationActive = false;
            this.updateLocationStatus();
            return false;
        }
    }

    startLocationTracking() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
        }

        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                this.updateLocation(position);
            },
            (error) => {
                console.error('Location error:', error);
                this.showNotification('Location tracking error', 'error');
            },
            {
                enableHighAccuracy: true,
                timeout: 30000,
                maximumAge: 60000
            }
        );

        this.showNotification('Location sharing started', 'success');
    }

    stopLocationTracking() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }
        this.showNotification('Location sharing stopped', 'info');
    }

    updateLocation(position) {
        const location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString(),
            address: null // Would be filled by reverse geocoding in real app
        };

        // Add to history
        this.locationHistory.push(location);
        
        // Keep only last 100 locations
        if (this.locationHistory.length > 100) {
            this.locationHistory = this.locationHistory.slice(-100);
        }

        // Update current user location
        if (this.currentUser) {
            this.currentUser.location = location;
        }

        // Simulate sending to partner
        this.sendLocationToPartner(location);
        
        // Update map display
        this.updateMapDisplay();
        
        this.saveData();
    }

    sendLocationToPartner(location) {
        // In a real app, this would send via WebSocket/API
        console.log('Sending location to partner:', location);
        
        // Simulate receiving partner's location update
        if (this.partner && Math.random() > 0.7) {
            this.simulatePartnerLocationUpdate();
        }
    }

    simulatePartnerLocationUpdate() {
        if (!this.partner) return;

        // Generate a nearby location for demo
        const baseLocation = this.currentUser?.location;
        if (baseLocation) {
            this.partner.location = {
                latitude: baseLocation.latitude + (Math.random() - 0.5) * 0.01,
                longitude: baseLocation.longitude + (Math.random() - 0.5) * 0.01,
                accuracy: 10,
                timestamp: new Date().toISOString(),
                address: 'Partner Location'
            };
        } else {
            this.partner.location = {
                latitude: 40.7128 + (Math.random() - 0.5) * 0.01,
                longitude: -74.0060 + (Math.random() - 0.5) * 0.01,
                accuracy: 10,
                timestamp: new Date().toISOString(),
                address: 'Partner Location'
            };
        }

        this.partner.lastSeen = new Date().toISOString();
        this.displayPartnerInfo();
        this.updateMapDisplay();
    }

    updateMapDisplay() {
        const mapContainer = document.getElementById('mapContainer');
        if (!mapContainer) return;

        let mapContent = '<div class="map-placeholder">';
        
        if (this.currentUser?.location || this.partner?.location) {
            mapContent = '<div class="map-placeholder" style="background: linear-gradient(45deg, #667eea, #764ba2); color: white;">';
            mapContent += '<div style="text-align: center;">';
            mapContent += '<h3>🗺️ Live Location Map</h3>';
            
            if (this.currentUser?.location) {
                mapContent += `<p>📍 Your Location: ${this.currentUser.location.latitude.toFixed(4)}, ${this.currentUser.location.longitude.toFixed(4)}</p>`;
            }
            
            if (this.partner?.location) {
                mapContent += `<p>💖 Partner Location: ${this.partner.location.latitude.toFixed(4)}, ${this.partner.location.longitude.toFixed(4)}</p>`;
                
                if (this.currentUser?.location) {
                    const distance = this.calculateDistance(
                        this.currentUser.location.latitude,
                        this.currentUser.location.longitude,
                        this.partner.location.latitude,
                        this.partner.location.longitude
                    );
                    mapContent += `<p>📏 Distance: ${distance.toFixed(2)} km</p>`;
                }
            }
            
            mapContent += '<p style="font-size: 0.8rem; opacity: 0.8;">In a real app, this would show an interactive map</p>';
            mapContent += '</div>';
        } else {
            mapContent += '<div>';
            mapContent += '<h3>🗺️ Location Map</h3>';
            mapContent += '<p>Enable location sharing to see the map</p>';
            mapContent += '</div>';
        }
        
        mapContent += '</div>';
        mapContainer.innerHTML = mapContent;
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Radius of the Earth in kilometers
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    deg2rad(deg) {
        return deg * (Math.PI/180);
    }

    updateConnectionStatus() {
        const statusElement = document.getElementById('connectionStatus');
        if (statusElement) {
            const statusClass = this.connectionStatus === 'connected' ? 'status-online' : 
                              this.connectionStatus === 'connecting' ? 'status-connecting' : 'status-offline';
            
            statusElement.innerHTML = `
                <span class="status-indicator ${statusClass}">
                    <span class="status-dot"></span>
                    ${this.connectionStatus}
                </span>
            `;
        }
    }

    updateLocationStatus() {
        const toggle = document.getElementById('locationToggle');
        if (toggle) {
            toggle.checked = this.isLocationActive;
        }

        const statusText = document.getElementById('locationStatus');
        if (statusText) {
            statusText.textContent = this.isLocationActive ? 'Location sharing is ON' : 'Location sharing is OFF';
        }
    }

    updateNotificationStatus() {
        const statusElement = document.getElementById('notificationStatus');
        if (statusElement) {
            const status = this.notifications.enabled ? 'Enabled' : 'Disabled';
            statusElement.textContent = `Notifications: ${status}`;
        }
    }

    async requestNotificationPermission() {
        if (!('Notification' in window)) {
            this.showNotification('This browser does not support notifications', 'error');
            return;
        }

        const permission = await Notification.requestPermission();
        this.notifications.permission = permission;
        this.notifications.enabled = permission === 'granted';
        
        this.updateNotificationStatus();
        this.saveData();
        
        if (permission === 'granted') {
            this.showNotification('Notifications enabled successfully', 'success');
            this.sendNotification('Couple Tracker', 'Notifications are now enabled!');
        } else {
            this.showNotification('Notification permission denied', 'error');
        }
    }

    sendNotification(title, body, options = {}) {
        if (this.notifications.enabled && this.notifications.permission === 'granted') {
            new Notification(title, {
                body,
                icon: '/icons/icon-192x192.png',
                badge: '/icons/icon-192x192.png',
                ...options
            });
        }
    }

    checkNotificationPermission() {
        if ('Notification' in window) {
            this.notifications.permission = Notification.permission;
            this.notifications.enabled = Notification.permission === 'granted';
        }
    }

    togglePrivacyZone(enabled) {
        if (enabled) {
            this.showNotification('Privacy zone activated - location sharing paused', 'info');
            this.stopLocationTracking();
        } else {
            this.showNotification('Privacy zone deactivated', 'info');
            if (this.isLocationActive) {
                this.startLocationTracking();
            }
        }
    }

    triggerEmergency() {
        this.emergencyMode = true;
        this.showNotification('Emergency mode activated!', 'error');
        
        // Force enable location sharing
        this.isLocationActive = true;
        this.requestLocationPermission();
        
        // Send emergency notification to partner
        if (this.partner) {
            this.sendNotification('Emergency Alert', 'Your partner has triggered emergency mode!');
        }
        
        // In a real app, this would send emergency alerts to contacts
        console.log('Emergency mode activated - sending alerts...');
    }

    disconnect() {
        if (confirm('Are you sure you want to disconnect from your partner?')) {
            this.partner = null;
            this.connectionCode = null;
            this.connectionStatus = 'disconnected';
            this.stopLocationTracking();
            this.isLocationActive = false;
            
            // Clear stored data
            localStorage.removeItem('coupleTracker_connection');
            
            this.updateConnectionStatus();
            this.updateLocationStatus();
            
            const partnerInfo = document.getElementById('partnerInfo');
            if (partnerInfo) partnerInfo.style.display = 'none';
            
            const codeDisplay = document.getElementById('connectionCodeDisplay');
            if (codeDisplay) codeDisplay.style.display = 'none';
            
            this.showNotification('Disconnected from partner', 'info');
        }
    }

    simulateConnection() {
        this.connectionStatus = 'connecting';
        this.updateConnectionStatus();
        
        setTimeout(() => {
            this.connectionStatus = 'connected';
            this.updateConnectionStatus();
        }, 2000);
    }

    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showNotification('Copied to clipboard!', 'success');
        }).catch(() => {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            this.showNotification('Copied to clipboard!', 'success');
        });
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => notification.classList.add('show'), 100);
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => document.body.removeChild(notification), 300);
        }, 3000);
    }

    generateUserId() {
        return 'user_' + Math.random().toString(36).substr(2, 9);
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
        return date.toLocaleDateString();
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.coupleTracker = new CoupleTracker();
});

// Service Worker registration for PWA functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
                console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}