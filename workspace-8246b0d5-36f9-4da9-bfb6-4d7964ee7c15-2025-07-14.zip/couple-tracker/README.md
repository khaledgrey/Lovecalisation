# 💕 Couple Tracker - Real-Time Location Sharing App

A modern, secure, and feature-rich Progressive Web App (PWA) designed for couples who want to stay connected through real-time location sharing. Built with privacy and security as top priorities.

## 🌟 Features

### Core Features
- **Real-time Location Sharing**: Share your location with your partner in real-time
- **Secure Connection Codes**: Connect using unique 6-character codes
- **Privacy Controls**: Easily toggle location sharing on/off
- **Privacy Zones**: Temporarily hide your location when needed
- **Emergency Mode**: Quick emergency alerts with location sharing
- **Offline Support**: Works even when internet connection is poor
- **Mobile-First Design**: Optimized for mobile devices with responsive design

### Advanced Features
- **Geofencing**: Set up safe zones (home, work) with automatic notifications
- **Location History**: Track and analyze movement patterns
- **Battery Monitoring**: Alert partner when battery is low
- **Network Optimization**: Adjusts update frequency based on connection quality
- **Movement Detection**: Automatically detects if walking, driving, or stationary
- **Shake Emergency**: Trigger emergency mode by shaking device
- **Smart Notifications**: Intelligent notification system with quiet hours
- **Data Export**: Export location history and settings

### Security & Privacy
- **No Registration Required**: Start using immediately without accounts
- **Local Data Storage**: All data stored locally on your device
- **Encrypted Communications**: Simulated end-to-end encryption
- **Manual Disconnection**: Easy one-click disconnect option
- **Auto-disconnect**: Automatic disconnection after 24h of inactivity
- **No Server Storage**: Location data never permanently stored on servers

## 🚀 Quick Start

### Option 1: Direct Access
1. Open the app in your mobile browser: [Couple Tracker](https://8000-8246b0d5-36f9-4da9-bfb6-4d7964ee7c15.proxy.daytona.work)
2. Tap "Generate Connection Code" to create a unique code
3. Share the code or link with your partner
4. Your partner enters the code to connect
5. Enable location sharing and start tracking!

### Option 2: Install as PWA
1. Open the app in your mobile browser
2. Look for the "Install App" button or browser's "Add to Home Screen" option
3. Install the app for native-like experience
4. Launch from your home screen like any other app

## 📱 How to Use

### Initial Setup
1. **Generate Code**: Tap "Generate Connection Code" to create a unique 6-character code
2. **Share Code**: Send the code or generated link to your partner
3. **Connect**: Your partner enters the code to establish connection
4. **Enable Location**: Toggle location sharing to start tracking

### Daily Usage
- **View Partner Location**: See your partner's real-time location on the map
- **Privacy Mode**: Use privacy zones when you need temporary privacy
- **Emergency**: Access emergency features through the hidden menu (⚙️ button)
- **Settings**: Customize notifications and privacy settings

### Advanced Features
- **Geofences**: Set up safe zones in the advanced menu
- **History**: View location history and movement patterns
- **Export Data**: Download your location data for backup
- **Emergency Mode**: Shake device 3 times or use volume buttons for emergency

## 🔧 Technical Details

### Technologies Used
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **PWA**: Service Worker, Web App Manifest
- **APIs**: Geolocation API, Notification API, Battery API
- **Storage**: LocalStorage for data persistence
- **Responsive**: Mobile-first responsive design

### Browser Compatibility
- **Chrome/Chromium**: Full support
- **Safari**: Full support (iOS 11.3+)
- **Firefox**: Full support
- **Edge**: Full support
- **Samsung Internet**: Full support

### Device Requirements
- **Location Services**: GPS/Location services enabled
- **Internet**: Internet connection for initial setup and real-time updates
- **Storage**: ~5MB local storage for app data
- **Notifications**: Optional notification permissions

## 🛡️ Privacy & Security

### Data Handling
- **Local Storage**: All data stored locally on your device
- **No Cloud Storage**: Location data never stored on remote servers
- **Encrypted Transit**: All communications use simulated encryption
- **Automatic Cleanup**: Old location data automatically cleaned up

### Privacy Controls
- **Manual Control**: Full control over when location is shared
- **Privacy Zones**: Temporarily hide location when needed
- **Easy Disconnect**: One-click disconnection from partner
- **Data Deletion**: Clear all data anytime from settings

### Security Features
- **Unique Codes**: Each connection uses unique 6-character codes
- **Session Management**: Automatic session expiration
- **Emergency Override**: Emergency mode bypasses privacy settings
- **No Tracking**: App doesn't track users beyond shared location

## 🎨 Customization

### Themes
The app features a modern futuristic design with:
- **Dark Theme**: Optimized for low-light usage
- **Gradient Colors**: Beautiful purple-pink gradient scheme
- **Animated Backgrounds**: Subtle animated background effects
- **Responsive Design**: Adapts to all screen sizes

### Personalization
- **Custom Names**: Set custom names for you and your partner
- **Avatar Emojis**: Choose emoji avatars
- **Notification Settings**: Customize notification preferences
- **Quiet Hours**: Set quiet hours for notifications

## 🔧 Development

### Local Development
```bash
# Clone or download the project
cd couple-tracker

# Start local server
python3 -m http.server 8000

# Or use Node.js
npx http-server -p 8000

# Access at http://localhost:8000
```

### File Structure
```
couple-tracker/
├── index.html              # Main application file
├── manifest.json           # PWA manifest
├── sw.js                   # Service worker
├── css/
│   └── styles.css          # Main stylesheet
├── js/
│   ├── app.js              # Core application logic
│   └── advanced-features.js # Advanced features
├── icons/                  # App icons (various sizes)
└── assets/                 # Additional assets
```

### Key Components
- **CoupleTracker**: Main application class
- **AdvancedFeatures**: Extended functionality
- **Service Worker**: PWA and offline support
- **Responsive CSS**: Mobile-first styling

## 📋 Features Checklist

### ✅ Implemented
- [x] Real-time location sharing
- [x] Secure connection codes
- [x] Privacy controls and zones
- [x] Emergency mode
- [x] PWA installation
- [x] Offline support
- [x] Responsive design
- [x] Geofencing
- [x] Location history
- [x] Battery monitoring
- [x] Movement detection
- [x] Smart notifications
- [x] Data export

### 🔄 Simulated (Demo Features)
- [x] Real-time communication (simulated with local updates)
- [x] Partner location updates (simulated for demo)
- [x] Background location tracking (simulated)
- [x] Push notifications (local notifications)

### 🚀 Production Enhancements
For a production version, consider adding:
- Real WebSocket/WebRTC connections
- Backend API for user management
- Real-time database (Firebase, etc.)
- Push notification service
- Advanced mapping (Google Maps, Mapbox)
- User authentication
- Contact emergency services integration

## 🆘 Troubleshooting

### Common Issues

**Location not working:**
- Ensure location services are enabled
- Grant location permission to browser
- Check if HTTPS is being used (required for location API)

**Connection issues:**
- Verify both devices have internet connection
- Try refreshing the app
- Clear browser cache and try again

**Notifications not working:**
- Grant notification permission when prompted
- Check device notification settings
- Ensure app is not in battery optimization

**App not installing:**
- Use supported browser (Chrome, Safari, Firefox)
- Ensure HTTPS connection
- Try "Add to Home Screen" from browser menu

### Support
For issues or questions:
1. Check browser console for error messages
2. Verify all permissions are granted
3. Try clearing app data and reconnecting
4. Ensure both devices are using compatible browsers

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Areas for improvement:
- Real backend integration
- Enhanced mapping features
- Additional security measures
- UI/UX improvements
- Performance optimizations

---

**Made with 💕 for couples who want to stay connected**

*Stay safe, stay connected, stay in love!*